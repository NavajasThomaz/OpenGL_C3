# OpenGL_C3_Staircase
 glfw, glfw.GLFW as GLFW_CONSTANTS, OpenGL.GL, OpenGL.GL.shaders project to show C3 staircase
