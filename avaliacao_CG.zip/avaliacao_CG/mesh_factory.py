from config import *


def build_textured_quad():
    """ Builds a textured quad. """
    vertex_data = np.array([
        -0.5, -0.5, 0.0, 0.0, 0.0,
        0.5, -0.5, 0.0, 1.0, 0.0,
        0.5, 0.5, 0.0, 1.0, 1.0,
        -0.5, 0.5, 0.0, 0.0, 1.0,
        -0.5, -0.5, 0.0, 0.0, 0.0,
        0.5, 0.5, 0.0, 1.0, 1.0
    ], dtype=np.float32)

    vao = glGenVertexArrays(1)
    vbo = glGenBuffers(1)

    glBindVertexArray(vao)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, vertex_data.nbytes, vertex_data, GL_STATIC_DRAW)

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * 4, ctypes.c_void_p(0))
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * 4, ctypes.c_void_p(12))
    glEnableVertexAttribArray(1)

    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    return vao, vbo


def create_vao(vertices, indices):
  """Cria um VAO e VBOs para o modelo."""
  vao = glGenVertexArrays(1)
  glBindVertexArray(vao)

  # VBO para vértices
  vbo_vertices = glGenBuffers(1)
  glBindBuffer(GL_ARRAY_BUFFER, vbo_vertices)
  glBufferData(GL_ARRAY_BUFFER, vertices.size * vertices.itemsize, vertices, GL_STATIC_DRAW)
  glEnableVertexAttribArray(0)
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)

  # VBO para normais
  vbo_normals = glGenBuffers(1)
  glBindBuffer(GL_ARRAY_BUFFER, vbo_normals)
  #glBufferData(GL_ARRAY_BUFFER, normals.size * normals.itemsize, normals, GL_STATIC_DRAW)
  glEnableVertexAttribArray(1)
  glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, None)

  # EBO para índices
  ebo = glGenBuffers(1)
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo)
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size * indices.itemsize, indices, GL_STATIC_DRAW)

  glBindVertexArray(0)
  return vao


    