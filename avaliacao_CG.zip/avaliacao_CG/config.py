import glfw
import glfw.GLFW as GLFW_CONSTANTS
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
from PIL import Image
import numpy as np

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480


def load_image(filepath):
    """ Carrega uma imagem e retorna como um objeto Image. """
    return Image.open(filepath).convert('RGBA')


def create_texture(image):
    """ Cria uma textura OpenGL a partir de um objeto Image. """
    texture = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.width, image.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image.tobytes())
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glBindTexture(GL_TEXTURE_2D, 0)
    return texture


def create_shader_program(vertex_file_path, fragment_file_path):
    vertex_shader = compileShader(open(vertex_file_path).read(), GL_VERTEX_SHADER)
    fragment_shader = compileShader(open(fragment_file_path).read(), GL_FRAGMENT_SHADER)
    shader_program = compileProgram(vertex_shader, fragment_shader)

    # Verifique se houve erro na compilação
    if not shader_program:
        print("Shader program failed to compile.")
        return None

    return shader_program
